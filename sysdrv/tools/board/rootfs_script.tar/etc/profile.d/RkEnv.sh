export HOME=/oem
export PATH=$PATH:$HOME:$HOME/bin:$HOME/usr/bin:$HOME/sbin:$HOME/usr/sbin
export LD_LIBRARY_PATH=$HOME/usr/lib:$HOME/lib:$LD_LIBRARY_PATH
